#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <ctime>
#include <exception>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <random>
#include <string>
#include <utility>
#include <vector>
#include <map>
#include <array>
#include <unordered_set>
#include <set>

// model parameters
const int iFirstGen = 7;           //Number of parents in the first generation
const int i1stGNRP = 4;            //Number of non-related parents from the first generation
const int i1stGNRf = 2;            //Number of non-related parents from the first generation and they are females
const int NumRepeats = 10;
const int NumReintro = 10;
const int iClutchSize = 3;
const double dNestlingSur = 0.62;    //survival rate during the nestling stage
const double a = -1;            //parameter 1 for offspring survival and IC
const double b = 0.90;              //parameter 2 for offspring survival and IC, the hatchng success when IC = 0.73+1*0.17
const double dMorRateAdu = 0.05;    //when assume uniform adult mortality rate regardless of age;
const double dMorRateJuv = 0.22;    //Juvenile mortality rate
const double dMorRateJuv2 = 0.05;
const double dNestSur = 0.62;


int iNumMigrationPair1 = 3;
int iNumMigrationPair2 = 11;

int MigrationInterval = 3;



// Obtain seed from system clock
std::chrono::high_resolution_clock::time_point tp =
std::chrono::high_resolution_clock::now();
unsigned seed = static_cast<unsigned>(tp.time_since_epoch().count());


// Create and seed pseudo-random number generator
std::mt19937_64 rng;

enum Sex { female, male };

enum pop_type { leader, follower3, firework3, follower11, firework11 };

//Structure
class Individual {
public:
	int iAge = 0;
	pop_type population = leader;
	Sex Sex_;
	std::pair<int, int> ParentsID;
	size_t iID;
	int iNumOffs;              //how many offspring it produced this round
	double dICadd1;                   //inbreeding coefficients+1
	int iPairYears = 0;                 //how many year they are together as a pair
	int iPairNumOffs;                  //how many offspring this pair has until now
	double dIC;
	std::vector<double> vMatrixCol;

	Individual() {
		Sex_ = Sex::female;
		iAge = 0;
	}

	void set_sex(const Sex& s) {
		Sex_ = s;
	}
	void set_ID(const int& ID) {
		iID = ID;
	}

private:
	int ID;
};

struct IC_track {
	int ID = -1;
	double diag = -1;
	int mother = -1;
	int father = -1;
	bool founder = false;

	IC_track(int x, bool init) : ID(x), founder(init) {                 //if the individual is founder, then diag value of the matrix is 1
		if (founder) diag = 1.0;
	};
	IC_track(int x, int m, int f) : ID(x), founder(false), mother(m), father(f) {

	};
};


double get_IC(std::vector<IC_track>& pop,
	int i, int j,
	std::map<std::pair<int, int>, double>& lookup) {
	if (i > j) std::swap(i, j);
	auto lookup_answ = lookup.find(std::pair<int, int>(i, j));
	if (lookup_answ != lookup.end()) {
		return lookup_answ->second; //return the second item in the lookup, which is the IC
	}

	double answ = 0.0;
	if (i == j) {
		answ = pop[i].diag;
	}
	else if (i < i1stGNRP && j < i1stGNRP) {
		answ = 0.0;
	}
	else {
		if (j > pop.size()) throw "j out of bounds";
		auto m = pop[j].mother;
		auto f = pop[j].father;
		if (m > f) std::swap(m, f);

		double a_ip = get_IC(pop, m, i, lookup);
		double a_iq = get_IC(pop, f, i, lookup);

		answ = 0.5 * (a_ip + a_iq);
	}
	lookup.insert({ std::pair<int, int>{i, j}, answ });
	return answ;
}

void set_IC(std::vector<IC_track>& pop, int i,
	std::map<std::pair<int, int>, double>& lookup) {
	if (pop[i].diag > -1) return;

	auto m = pop[i].mother;
	auto f = pop[i].father;
	if (m > f) std::swap(m, f);  //swap the value of m and f?

	double a_pq = get_IC(pop, m, f, lookup);
	pop[i].diag = 1 + 0.5 * a_pq;
	return;
}


void update_IC(std::vector<IC_track>& pop,
	std::map<std::pair<int, int>, double>& lookup) {
	for (int i = static_cast<int>(pop.size()) - 1; i >= 0; --i) {
		set_IC(pop, i, lookup);
	}
}

void Set_offs(std::pair<Individual, Individual>& pairs,
	double& IC,
	std::vector<Individual>& voffspring,

	size_t& IDPool,
	std::vector< IC_track >& track)
{
	Individual Offs;
	std::bernoulli_distribution givesex(0.5);
	Offs.Sex_ = static_cast<Sex>(givesex(rng));   //give sex
	Offs.ParentsID.first = pairs.first.iID;
	Offs.ParentsID.second = pairs.second.iID;
	Offs.iID = IDPool;
	IDPool++;
	Offs.dIC = IC;
	Offs.population = pairs.first.population;
	track.push_back(IC_track(Offs.iID, pairs.first.iID, pairs.second.iID));
	voffspring.push_back(Offs);
}


void Makingpairs(const std::vector<Individual>& males,
	const std::vector<Individual>& females,
	std::vector< std::pair<Individual, Individual>>& pairs,
	std::vector<Individual>& singles)
{
	if (!males.empty() || !females.empty()) {
		size_t iNumPairs = males.size();
		if (males.size() > females.size()) {
			iNumPairs = females.size();
			for (size_t a = iNumPairs; a < males.size(); ++a)
				singles.push_back(males[a]);
		}
		else if (males.size() < females.size()) {
			iNumPairs = males.size();
			for (size_t b = iNumPairs; b < females.size(); ++b)
				singles.push_back(females[b]);
		}

		if (iNumPairs != 0) {
			for (size_t j = 0; j < iNumPairs; ++j) {
				std::pair<Individual, Individual> couple(males[j], females[j]);
				//couple.first.iPairYears = coupleayi1.second.iPairYears = 1; *this is not used for now, because it seems not useful. If I want to add this back again, I can go to the RemoveDeath function to update the marriage age
				pairs.push_back(couple);
			}
		}
	}

}

std::vector<Individual> extract_individuals(const std::vector<Individual>& v,
	pop_type focal_pop) {
	std::vector<Individual> result;
	if (!v.empty()) {
		for (const auto& i : v) {
			if (i.population == focal_pop) result.push_back(i);
		}
	}
	return result;
}

void Makingpairs_FL(const std::vector<Individual>& males,
	const std::vector<Individual>& females,
	std::vector< std::pair<Individual, Individual>>& pairs,
	std::vector<Individual>& singles)
{
	// make two subqueues of males and females in each habitat

	for (auto focal_pop = 0; focal_pop <= 4; ++focal_pop) {

		std::vector<Individual> local_males = extract_individuals(males, static_cast<pop_type>(focal_pop));
		std::vector<Individual> local_females = extract_individuals(females, static_cast<pop_type>(focal_pop));
		if (!local_males.empty() && !local_females.empty())
			Makingpairs(local_males, local_females, pairs, singles);
	}
}

void OffsProduce(std::pair<Individual, Individual>& pairs,
	std::vector<Individual>& voffspring,
	size_t& IDPool,
	std::vector< IC_track >& track,
	std::map< std::pair<int, int>, double>& lookup_map)
{

	double IC = 0.5 * get_IC(track, pairs.first.iID, pairs.second.iID, lookup_map);

	std::bernoulli_distribution NestSur(dNestSur);

	if (NestSur(rng) == true) {
		//calculate the number of survived offspring
		if ((a * IC + b) > 0) {
			double dIdealNum = iClutchSize * (a * IC + b);               //Ideal number of hatchings  Hs = a*IC+b
			std::poisson_distribution<int>NumOffs(dIdealNum * dNestlingSur);   //Number of fledglings = Number of hatching * Survival success of nestling stage
			int iSurvivor = NumOffs(rng);
			if (iSurvivor > 3) iSurvivor = 3;

			if (iSurvivor > 0) {
				//give parents ID, sibling ID, matrix expansion
				for (int i = 0; i < iSurvivor; ++i) {
					Set_offs(pairs, IC, voffspring, IDPool, track);
				}
			}
		}
	}
}

void RemoveDeath(std::vector<Individual >& singles,
	std::vector<Individual >& offspring,
	std::vector< std::pair< Individual, Individual> >& pairs,
	std::vector<Individual>& death, std::vector<Individual>& juveniel)
{
	std::binomial_distribution<size_t>MorAduS(singles.size(), dMorRateAdu);
	std::binomial_distribution<size_t>MorJuv(offspring.size(), dMorRateJuv);
	std::binomial_distribution<size_t>MorJuv2(juveniel.size(), dMorRateJuv2);  //for the juveniels who are 2 years old
	std::binomial_distribution<size_t>MorAduP((pairs.size() * 2), dMorRateAdu);
	//the number of  singles, juveniels, dead adults parents,and how many dead in pairs in those dead adults

	if (!singles.empty()) {
		shuffle(singles.begin(), singles.end(), rng);
		size_t DeadAduS = MorAduS(rng);
		if (DeadAduS != 0) {
			for (size_t n = 0; n < DeadAduS; ++n) {
				death.push_back(singles.back());   //move the dead one to death vector
				singles.pop_back();     //remove the dead Single adults
			}
		}
	}

	if (!offspring.empty()) {
		shuffle(offspring.begin(), offspring.end(), rng);
		size_t DeadJuv = MorJuv(rng);
		if (DeadJuv != 0) {
			for (size_t n = 0; n < DeadJuv; ++n) {
				death.push_back(offspring.back()); //move the dead one to death vector
				offspring.pop_back();      //remove the dead offspring
			}
		}
	}

	if (!juveniel.empty()) {
		shuffle(juveniel.begin(), juveniel.end(), rng);
		size_t DeadJuv = MorJuv2(rng);
		if (DeadJuv != 0) {
			for (size_t n = 0; n < DeadJuv; ++n) {
				death.push_back(juveniel.back()); //move dead ones to death vector
				juveniel.pop_back();      //remove the dead juvenile
			}
		}
	}


	if (!pairs.empty())
		shuffle(pairs.begin(), pairs.end(), rng);
	size_t  DeadAduP = MorAduP(rng);
	if (DeadAduP != 0) {
		std::binomial_distribution<size_t>MorAduPairDead(DeadAduP, dMorRateAdu);  //the pairs both dead in the same season
		size_t DeadPair = MorAduPairDead(rng);
		if (DeadPair > pairs.size()) DeadPair = pairs.size();    //in case of very very very very very small chance that DeadPair > pairs.size

		//remove the dead parents
		if (DeadPair != 0) {                                       //if there are pairs (both) have to die
			if (DeadPair > pairs.size()) DeadPair = pairs.size();
			for (size_t n = 0; n < DeadPair; ++n) pairs.pop_back();   // remove the dead pair(s)

			size_t RemaintoRemove = DeadAduP - 2 * DeadPair;          //how many parents need to be removed from the remaining pairs
			if (RemaintoRemove > pairs.size()) RemaintoRemove = pairs.size();

			for (size_t n = 0; n < RemaintoRemove; ++n) {  //move the alive one to vSingles, and move the dead completely out of the vPairs
				std::bernoulli_distribution Selectone(0.5);
				Selectone(rng) == 0 ? singles.push_back(pairs.back().first) : singles.push_back(pairs.back().second);
				singles.back().iPairYears = 0;
				singles.back().Sex_ == 0 ? death.push_back(pairs.back().first) : death.push_back(pairs.back().second); //put the death parent to the dead vector
				pairs.pop_back();
			}
		}

		else if (DeadAduP != 0 && DeadPair == 0) {
			if (DeadAduP > pairs.size()) DeadAduP = pairs.size();
			for (size_t n = 0; n < DeadAduP; ++n) {
				std::bernoulli_distribution Selectone(0.5);
				Selectone(rng) == 0 ? singles.push_back(pairs.back().first) : singles.push_back(pairs.back().second);
				singles.back().iPairYears = 0;
				singles.back().Sex_ == 0 ? death.push_back(pairs.back().first) : death.push_back(pairs.back().second); //put the death parent to the dead vector
				pairs.pop_back();
			}
		}
	}
}

void CheckAge(std::vector< std::pair< Individual, Individual> >& pairs,
	std::vector<Individual >& males,
	std::vector<Individual >& females) {

	if (pairs.empty()) return;

	for (int i = pairs.size() - 1; i >= 0; --i) {
		if (pairs[i].first.iAge >= 20 && pairs[i].second.iAge < 20) {
			females.push_back(pairs[i].second);
			pairs[i] = pairs.back();
			pairs.pop_back();
		}
		else if (pairs[i].first.iAge < 20 && pairs[i].second.iAge >= 20) {
			males.push_back(pairs[i].first);
			pairs[i] = pairs.back();
			pairs.pop_back();
		}
		else if (pairs[i].first.iAge >= 20 && pairs[i].second.iAge >= 20) {
			pairs[i] = pairs.back();
			pairs.pop_back();
		}
	}

	for (int i = males.size() - 1; i >= 0; --i) {
		if (males[i].iAge >= 20) {
			males[i] = males.back();
			males.pop_back();
		}
	}

	for (int i = females.size() - 1; i >= 0; --i) {
		if (females[i].iAge >= 20) {
			females[i] = females.back();
			females.pop_back();
		}
	}
}

std::array<size_t, 5> count_indivs(const std::vector<std::pair< Individual, Individual>>& pairs,
	const std::vector<Individual>& males,
	const std::vector<Individual>& females,
	const std::vector<Individual>& juveniles) {
	std::array<size_t, 5> out = { 0, 0, 0, 0, 0 };
	for (const auto& i : pairs) {
		out[i.first.population]++;
		out[i.second.population]++;
	}

	for (const auto& i : males) {
		out[i.population]++;
	}

	for (const auto& i : females) {
		out[i.population]++;
	}

	for (const auto& i : juveniles) {
		out[i.population]++;
	}
	return out;
}

void CalculateIC(std::vector<double>& IC, double& Avg, double& Sum, double& SD)
{

	for (size_t i = 0; i < IC.size(); ++i) Sum += IC[i];
	Avg = Sum / IC.size();

	double dSumVar1 = 0.0;
	for (size_t i = 0; i < IC.size(); ++i) dSumVar1 += (IC[i] - Avg) * (IC[i] - Avg);
	SD = sqrt(dSumVar1 / (IC.size() - 1));

}

int main() {
	try
	{
		auto clock_start = std::chrono::system_clock::now();

		// draw random seed and log it
		rng.seed(seed);
		std::ofstream PopuInfo;
		std::ofstream PopuInfoOrig;
		PopuInfoOrig.open("Population Info_FLF_Orig.csv");
		PopuInfo.open("Population Info_FLF_One.csv");


		PopuInfoOrig << "Repeat" << "," << "Season" << "," << "PopuSize" << "," << "AvgIC" << "," << "SD" << std::endl;
		PopuInfo << "Repeat" << "," << "Season" << ","
			<< "PopuSize" << "," << "AvgIC" << "," << "SD" << ","
			<< "FollowerSize3" << "," << "AvgIC_Follower3" << "," << "SD_Follower3" << ","
			<< "FireworkSize3" << "," << "AvgIC_Firework3" << "," << "SD_Firework3" << ","
			<< "FollowerSize11" << "," << "AvgIC_Follower11" << "," << "SD_Follower11" << ","
			<< "FireworkSize11" << "," << "AvgIC_Firework11" << "," << "SD_Firework11" << std::endl;

		//Check if file is open, else error
		if (!PopuInfo.is_open() || !PopuInfoOrig.is_open())
			throw std::runtime_error("unable to open the file. \n");

		for (int iRepeat = 1; iRepeat < NumRepeats + 1; ++iRepeat) {
			std::vector<Individual> vStart;     //vICmatrix includes all individuals count in the ICmatrix
			//vPopulation includes all individuals in the population
			size_t IDPool = 0;
			std::vector<Individual> vFemales, vMales, vSingles, vOffspring, vDeath, vJuvenile;
			std::vector< std::pair< Individual, Individual> > vPairs;
			std::vector<double>vIC;    //used for store IC of breeding individuals in each year

			std::map< std::pair<int, int>, double> lookup_map;
			std::vector< IC_track > track;

			//create the first generation
			for (int i = 0; i < i1stGNRP; ++i) {
				Individual FirstGen;
				FirstGen.set_ID(IDPool);      //give ID from the IDpool in order
				IDPool++;
				FirstGen.dIC = 0.0;
				i < i1stGNRf ? FirstGen.set_sex(Sex::male) : FirstGen.set_sex(Sex::female);  //give sex to the first four non-related parents
				FirstGen.iAge = 1;
				FirstGen.population = leader;
				vStart.push_back(FirstGen);
				track.push_back(IC_track(FirstGen.iID, true));
			}

			update_IC(track, lookup_map);

			//I need to add three offspring with random sex to the matrix and the 1st Gen population
			vPairs.push_back(std::pair<Individual, Individual>(vStart[0], vStart[2]));
			vPairs.push_back(std::pair<Individual, Individual>(vStart[1], vStart[3]));


			double IC = 0.5 * get_IC(track, vPairs[0].first.iID, vPairs[0].second.iID, lookup_map);
			for (int j = 0; j < 3; ++j) {      //the first pair reproduced one offspring as a founder; the second pair reproduced two offspring as founders. 
				Set_offs(vPairs[0], IC, vOffspring, IDPool, track);
			}

			int m = 0;
			size_t Season = 0;
			double dAvgIC = 0.0, dAvgIC1 = 0.0, dAvgIC2 = 0.0, dAvgIC3 = 0.0, dAvgIC4 = 0.0;
			double sdIC = 0.0, sdIC1 = 0.0, sdIC2 = 0.0, sdIC3 = 0.0, sdIC4 = 0.0;
			//making breeding pairs

			std::array<size_t, 5> pop_count = count_indivs(vPairs, vMales, vFemales, vJuvenile);

			for (; ; ++Season) {
				shuffle(vMales.begin(), vMales.end(), rng);
				shuffle(vFemales.begin(), vFemales.end(), rng);
				Makingpairs(vMales, vFemales, vPairs, vSingles); //radomly pairing up

				//Update age
				for (size_t n = 0; n < vPairs.size(); ++n) {
					++vPairs[n].first.iAge;
					++vPairs[n].second.iAge;
					++vPairs[n].first.iPairYears;
					++vPairs[n].second.iPairYears;
				}
				for (size_t p = 0; p < vSingles.size(); ++p) ++vSingles[p].iAge;

				//mark parents ID for each new baby and put them to the offspring pool, extend ICmatrix
				for (size_t i = 0; i < vPairs.size(); ++i)
					OffsProduce(vPairs[i], vOffspring, IDPool, track, lookup_map);   //give ID, parents ID, sex

				//remove dead individuals and rearrange the survival ones survived parents and offspring over the season
				RemoveDeath(vSingles, vOffspring, vPairs, vDeath, vJuvenile);

				//clear the mating pool
				vMales.clear(); vFemales.clear();                           //clear mating pool for this season

				//add singles and offspring to the mating pool of the next season
				if (!vSingles.empty()) {
					for (size_t i = 0; i < vSingles.size(); ++i)
						vSingles[i].Sex_ == Sex::female ? vFemales.push_back(vSingles[i]) : vMales.push_back(vSingles[i]);
				}
				if (!vJuvenile.empty()) {
					for (size_t i = 0; i < vJuvenile.size(); ++i)            //add offspring to the mating pool for the next season
						vJuvenile[i].Sex_ == Sex::female ? vFemales.push_back(vJuvenile[i]) : vMales.push_back(vJuvenile[i]);
				}

				vJuvenile.clear();
				vSingles.clear();

				if (!vOffspring.empty()) {
					for (const auto& i : vOffspring) vJuvenile.push_back(i);
				}

				vOffspring.clear();

				//check adult age
				CheckAge(vPairs, vMales, vFemales);

				//#############OUTPUT########################
				//calculate the average IC of breeders in this season
				//first push back all the inviduals who is alive to the vIC vector
				if (!vPairs.empty()) {
					for (const auto& i : vPairs) {
						vIC.push_back(i.first.dIC);
						vIC.push_back(i.second.dIC);
					}
				}
				if (!vMales.empty()) for (const auto& i : vMales) vIC.push_back(i.dIC);
				if (!vFemales.empty()) for (const auto& i : vFemales) vIC.push_back(i.dIC);

				double dSum = 0.0;

				if (!vIC.empty()) {
					for (size_t i = 0; i < vIC.size(); ++i) dSum += vIC[i];
					dAvgIC = dSum / vIC.size();

					double dSumVar = 0.0;
					for (size_t i = 0; i < vIC.size(); ++i) dSumVar += (vIC[i] - dAvgIC) * (vIC[i] - dAvgIC);
					sdIC = sqrt(dSumVar / (vIC.size() - 1));
				}

				//Output population info
				PopuInfoOrig << iRepeat << "," << Season << "," << (vPairs.size() * 2 + vMales.size() + vFemales.size() + vJuvenile.size()) << "," << dAvgIC << "," << sdIC << std::endl;

				if ((vPairs.size() + vMales.size() + vFemales.size() + vJuvenile.size() == 0) || (vPairs.size() == 0 && (vMales.size() == 0 || vFemales.size() == 0) && vJuvenile.size() == 0)) {
					std::cout << "Population extinct!";
					m = 1;
					break;
				}

				vIC.clear();
				update_IC(track, lookup_map);

				// if the leader population > 1000, we create the followers
				pop_count = count_indivs(vPairs, vMales, vFemales, vJuvenile);
				std::cout << pop_count[0] << " " << pop_count[1] << " " << pop_count[2] << " " << pop_count[3] << "\n";
				if (pop_count[0] >= 1000) {
					break;
				}
			}

			std::cout << "Repeats:" << iRepeat << ", Season: " << Season << ", " << "Current size: " <<
				vPairs.size() * 2 + vFemales.size() + vMales.size() + vJuvenile.size() << std::endl;


			// ###############Reintroduction: seed second population with N pairs################
			if (m == 0) {
				if (vPairs.size() < iNumMigrationPair2) {
					throw "leader population is too small error!\n"; // this should never happen! If it does, we have to increase the 1000
				}

				std::uniform_int_distribution<> d(0, vPairs.size() - 1);

				for (size_t i = 0; i < iNumMigrationPair1; ) {
					auto index = d(rng);
					if (vPairs[index].first.population == leader) {
						vPairs[index].first.population = follower3;
						vPairs[index].second.population = follower3;
						++i;
					}
				}

				for (size_t i = 0; i < iNumMigrationPair1; ) {
					auto index = d(rng);
					if (vPairs[index].first.population == leader) {
						vPairs[index].first.population = firework3;
						vPairs[index].second.population = firework3;
						++i;
					}
				}

				for (size_t i = 0; i < iNumMigrationPair2; ) {
					auto index = d(rng);
					if (vPairs[index].first.population == leader) {
						vPairs[index].first.population = follower11;
						vPairs[index].second.population = follower11;
						++i;
					}
				}

				for (size_t i = 0; i < iNumMigrationPair2; ) {
					auto index = d(rng);
					if (vPairs[index].first.population == leader) {
						vPairs[index].first.population = firework11;
						vPairs[index].second.population = firework11;
						++i;
					}
				}

				pop_count = count_indivs(vPairs, vMales, vFemales, vJuvenile);
				std::cout << "Reintroduction Num:" << pop_count[0] << " " << pop_count[1] << " " << pop_count[2] << " " << pop_count[3] << "\n";

				size_t new_season = 1;

				// now we have two populations!
				for (; ; ++new_season) {
					shuffle(vMales.begin(), vMales.end(), rng);
					shuffle(vFemales.begin(), vFemales.end(), rng);

					Makingpairs_FL(vMales, vFemales, vPairs, vSingles); //randomly pairing up

					//Update age
					for (size_t n = 0; n < vPairs.size(); ++n) {
						++vPairs[n].first.iAge;
						++vPairs[n].second.iAge;
						++vPairs[n].first.iPairYears;
						++vPairs[n].second.iPairYears;
					}
					for (size_t p = 0; p < vSingles.size(); ++p) ++vSingles[p].iAge;

					//mark parents ID for each new baby and put them to the offspring pool, extend ICmatrix
					for (size_t i = 0; i < vPairs.size(); ++i)
						OffsProduce(vPairs[i], vOffspring, IDPool, track, lookup_map);   //give ID, parents ID, sex

					//remove dead individuals and rearrange the survival ones survived parents and offspring over the season
					RemoveDeath(vSingles, vOffspring, vPairs, vDeath, vJuvenile);

					//clear the mating pool
					vMales.clear(); vFemales.clear();                           //clear mating pool for this season

					//add singles and offspring to the mating pool of the next season
					if (!vSingles.empty()) {
						for (size_t i = 0; i < vSingles.size(); ++i)
							vSingles[i].Sex_ == Sex::female ? vFemales.push_back(vSingles[i]) : vMales.push_back(vSingles[i]);
					}
					if (!vJuvenile.empty()) {
						for (size_t i = 0; i < vJuvenile.size(); ++i)            //add offspring to the mating pool for the next season
							vJuvenile[i].Sex_ == Sex::female ? vFemales.push_back(vJuvenile[i]) : vMales.push_back(vJuvenile[i]);
					}

					vJuvenile.clear();
					vSingles.clear();

					if (!vOffspring.empty()) {
						for (const auto& i : vOffspring) vJuvenile.push_back(i);
					}

					vOffspring.clear();

					//check adult age
					CheckAge(vPairs, vMales, vFemales);

					//#############OUTPUT########################
					//calculate the average IC of breeders in this season
					//first push back all the inviduals who is alive to the vIC vector
					std::vector<double> vIC1, vIC2, vIC3, vIC4;
					if (!vPairs.empty()) {
						for (const auto& i : vPairs) {
							if (i.first.population == follower3) {
								vIC1.push_back(i.first.dIC);
								vIC1.push_back(i.second.dIC);
							}
							else if (i.first.population == firework3) {
								vIC2.push_back(i.first.dIC);
								vIC2.push_back(i.second.dIC);
							}
							else if (i.first.population == follower11) {
								vIC3.push_back(i.first.dIC);
								vIC3.push_back(i.second.dIC);
							}
							else if (i.first.population == firework11) {
								vIC4.push_back(i.first.dIC);
								vIC4.push_back(i.second.dIC);
							}

							else {
								vIC.push_back(i.first.dIC);
								vIC.push_back(i.second.dIC);
							}
						}
					}
					if (!vMales.empty()) {
						for (const auto& i : vMales) {
							if (i.population == follower3) vIC1.push_back(i.dIC); //To follower
							else if (i.population == firework3) vIC2.push_back(i.dIC);  //To firework
							else if (i.population == follower11) vIC3.push_back(i.dIC); //To follower
							else if (i.population == firework11) vIC4.push_back(i.dIC);  //To firework
							else vIC.push_back(i.dIC); //To leader
						}
					}

					if (!vFemales.empty()) {
						for (const auto& i : vFemales) {
							if (i.population == follower3) vIC1.push_back(i.dIC);//To follower
							else if (i.population == firework3) vIC2.push_back(i.dIC); //To firework
							else if (i.population == follower11) vIC3.push_back(i.dIC);//To follower
							else if (i.population == firework11) vIC4.push_back(i.dIC); //To firework
							else vIC.push_back(i.dIC); //To leader
						}
					}

					double dSum = 0.0, dSum1 = 0.0, dSum2 = 0.0, dSum3 = 0.0, dSum4 = 0.0;

					if (!vIC.empty()) CalculateIC(vIC, dAvgIC, dSum, sdIC);
					if (!vIC1.empty())CalculateIC(vIC1, dAvgIC1, dSum1, sdIC1);
					if (!vIC2.empty())CalculateIC(vIC2, dAvgIC2, dSum2, sdIC2);
					if (!vIC3.empty())CalculateIC(vIC3, dAvgIC3, dSum3, sdIC3);
					if (!vIC4.empty())CalculateIC(vIC4, dAvgIC4, dSum4, sdIC4);


					//Output population info
					if ((vPairs.size() + vMales.size() + vFemales.size() + vJuvenile.size() == 0) || (vPairs.size() == 0 && (vMales.size() == 0 || vFemales.size() == 0) && vJuvenile.size() == 0)) {
						std::cout << "Population extinct!";
						m = 1;
						break;
					}
					pop_count = count_indivs(vPairs, vMales, vFemales, vJuvenile);
					std::cout << pop_count[0] << " " << pop_count[1] << " " << pop_count[2] << " " << pop_count[3] << " " << pop_count[4] << "\n";
					PopuInfo << iRepeat << "," << new_season << "," << pop_count[0] << "," << dAvgIC << "," << sdIC << ","
						<< pop_count[1] << "," << dAvgIC1 << "," << sdIC1 << "," << pop_count[2] << "," << dAvgIC2 << "," << sdIC2 << ","
						<< pop_count[3] << "," << dAvgIC3 << "," << sdIC3 << "," << pop_count[4] << "," << dAvgIC4 << "," << sdIC4 << std::endl;

					vIC.clear(); vIC1.clear(); vIC2.clear(); vIC3.clear(); vIC4.clear();
					update_IC(track, lookup_map);



					if (new_season > 0 && new_season % MigrationInterval == 0 && new_season < 16) {
						// migrate pairs!
						// seed second population with N pairs
						if (vPairs.size() < iNumMigrationPair2) {
							throw "leader population is too small error!\n"; // this should never happen! If it does, we have to increase the 1000
						}
						std::uniform_int_distribution<> d(0, vPairs.size() - 1);
						for (size_t i = 0; i < iNumMigrationPair1; ) {
							auto index = d(rng);
							if (vPairs[index].first.population == leader) {
								vPairs[index].first.population = follower3;
								vPairs[index].second.population = follower3;
								++i;
							}
						}

						for (size_t i = 0; i < iNumMigrationPair2; ) {
							auto index = d(rng);
							if (vPairs[index].first.population == leader) {
								vPairs[index].first.population = follower11;
								vPairs[index].second.population = follower11;
								++i;
							}
						}
						std::cout << "INPUT" << std::endl;
					}

					std::vector<Individual> StopBreed;   //stop individuals from the original popuation from breeding
					std::vector< std::pair< Individual, Individual> > vPairNew;
					std::vector<Individual> vMaleNew, vFemaleNew, vJuvenileNew;

					if (new_season == 20) {
						for (auto i : vPairs) {
							if (i.first.population == 0) {
								StopBreed.push_back(i.first);
								StopBreed.push_back(i.second);
							}
							else vPairNew.push_back(i);
						}
						for (auto m : vMales) {
							if (m.population == 0) StopBreed.push_back(m);
							else vMaleNew.push_back(m);
						}

						for (auto f : vFemales) {
							if (f.population == 0) StopBreed.push_back(f);
							else vFemaleNew.push_back(f);
						}

						for (auto j : vJuvenile) {
							if (j.population == 0) StopBreed.push_back(j);
							else vJuvenileNew.push_back(j);
						}

						vPairs = std::move(vPairNew);
						vMales = std::move(vMaleNew);
						vFemales = std::move(vFemaleNew);
						vJuvenile = std::move(vJuvenileNew);
					}

					if (pop_count[1] >= 1000 || pop_count[3] >= 1000) {
						break;
					}
				}
			}

		}
		PopuInfo.close();
		PopuInfoOrig.close();
	}

	catch (std::exception& error)
	{
		std::cerr << error.what();
		exit(EXIT_FAILURE);
	}
	return 0;
}
