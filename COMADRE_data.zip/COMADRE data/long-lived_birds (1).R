# load libraries
library(Rcompadre)
library(Rage)
library(ggplot2)
library(readxl)
library(dplyr)

# load data from comadre
comadre <- cdb_fetch("comadre")

# filter data for bird species without missing values in matrices
birds <- subset(cdb_flag(comadre, "check_NA_U"), Class == "Aves" & check_NA_U == FALSE)

# there are often multiple matrices per species (e.g., data over several years)
# we can combine them if they have the same (st)age structure
birds$stage_id <- cdb_id_stages(birds)
birds_spec <- cdb_collapse(birds, "stage_id")

# overview of species data after combining matrices
CompadreData(birds_spec)[, c("SpeciesAccepted", "MatrixPopulation")]

# read in the excel file to extract names of the long-lived birds
bird_names_excel <- read_excel("long-lived_birds(2).xlsx") 
birds_of_interest <- bird_names_excel$commonname

# initialise list to store data
species_graphs_data <- list()

# loop through species
for (species_name in birds_of_interest) {
  # filter data for current species
  selected_indices <- which(birds_spec@data[["CommonName"]] == species_name)
  selected_observations <- birds_spec@data[selected_indices, ]
  
  # initialise list for storing data of a species (some species have more than 1 matrix)
  species_data <- list()
  
  # loop through matrices of current species
  for (i in seq_along(selected_observations$mat)) {
    # extract and append relevant data
    matrix_class <- selected_observations$mat[[i]]@matrixClass
    matU <- selected_observations$mat[[i]]@matU
    matrix_class_author <- as.character(matrix_class$MatrixClassAuthor)
    
    # if it's a 2x2 matrix, the relevant survival data is in the 2nd row
    if (nrow(matU) == 2 && ncol(matU) == 2) {
      mortality_probabilities <- 1 - matU[2, ] # mortality = 1 - survival
    } 
    # for all other matrix sizes, the relevant survival data is on the subdiagonal, except the final entry on the diagonal
    else {
      adjacent_values <- 1 - diag(matU[-1, -ncol(matU)]) # mortality = 1 - survival
      last_diagonal_value <- 1 - as.numeric(matU[nrow(matU), ncol(matU)]) # mortality = 1 - survival
      mortality_probabilities <- c(adjacent_values, last_diagonal_value)
    }
    
    # combine (st)age category names and survival data into one data frame for saving and plotting
    data <- data.frame(Category = factor(matrix_class_author[1:length(mortality_probabilities)], levels = unique(matrix_class_author)), 
                       MortalityProbability = mortality_probabilities)
    
    # plot data
    graph <- ggplot(data, aes(x = Category, y = MortalityProbability)) +
      geom_point() +
      ylim(0, 1) +
      labs(x = "(St)age", y = "Per-capita mortality probability") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
      ggtitle(paste(species_name, "Matrix", i))
    
    # storing graph and data frame for the current matrix
    species_data[[i]] <- list(graph = graph, data = data)
  }
  
  # storing the species data in the main list
  species_graphs_data[[species_name]] <- species_data
}

# to print to screen all species data frames and plots
#print(species_graphs_data)

# initialise data frame for final data
final_data <- data.frame(LatinName = character(),
                               SpeciesName = character(),
                               Category = character(),
                               MortalityProbability = numeric(),
                               stringsAsFactors = FALSE)

# loop through each species in list
for (species_name in names(species_graphs_data)) {
  # extract Latin name of current species
  latin_name <- bird_names_excel$genus[bird_names_excel$commonname == species_name] %>%
    paste(bird_names_excel$species[bird_names_excel$commonname == species_name], collapse = " ")
  
  # loop through the data frame(s) of the current species and extract/combine data
  for (i in seq_along(species_graphs_data[[species_name]])) {
    current_data <- species_graphs_data[[species_name]][[i]]$data
    current_data$LatinName <- latin_name
    current_data$SpeciesName <- species_name
    
    # if there are 2 matrices for a species, we rename the category names (_x) to differentiate them 
    if (length(species_graphs_data[[species_name]]) > 1) {
      current_data$Category <- paste(current_data$Category, i, sep = "_")
    }
    
    # append current species data to final data frame
    final_data <- bind_rows(final_data, current_data)
  }
}

# output data frame to csv file
write.csv(final_data, "long-lived_birds_mortality.csv", row.names = FALSE)

####################################
# initialise data frame for outputting references for data in the COMADRE database 
ref_data <- data.frame(LatinName = character(),
                            SpeciesName = character(),
                            DOI_ISBN = character(),
                            Journal = character(),
                            YearPublication = character(),
                            Authors = character(),
                            stringsAsFactors = FALSE)

# iterate over species output in other csv data file
for (species_name in unique(all_species_data$SpeciesName)) {
  # extract species common name
  species_row <- which(birds_spec@data[["CommonName"]] == species_name)
  
  # extract other corresponding data for referencing
  ref_info <- birds_spec@data[species_row, c("SpeciesAccepted", "CommonName", "DOI_ISBN", "Journal", "YearPublication", "Authors")]
  names(ref_info) <- c("LatinName", "SpeciesName", "DOI_ISBN", "Journal", "YearPublication", "Authors")
  
  # append current species data to ref data frame
  ref_data <- bind_rows(ref_data, ref_info)
}

# output reference data to csv file
write.csv(ref_data, "data_references.csv", row.names = FALSE)



