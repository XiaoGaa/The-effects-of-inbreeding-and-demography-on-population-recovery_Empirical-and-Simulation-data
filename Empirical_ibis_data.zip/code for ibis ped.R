setwd("E:/experiments_new_CHINA/behavioral ecology and evolutionary genetics/���q��Ⱥ׳��/data set/Pedigree_IBIS")
## install.packages("pedantics") #from download local
library(pedantics)
library(ggplot2)
ped_ibis <- read.csv('ped_ibis.csv',head= T)
head(ped_ibis)
drawPedigree(ped_ibis)

ped_ibis_fixed <-fixPedigree(Ped=ped_ibis)

ped_sum<-pedigreeStats(ped_ibis_fixed,graphicalReport='n')
str(ped_sum)
ggsave(file="ibis_ped.png", drawPedigree(ped_ibis), width = 15, height = 15, units = 'in', dpi = 800) 
capture.output(ped_sum, file = "Ibis_ped_summary.csv")
write.csv(ped_sum$Amatrix, 'Ibis_ped_matrix.csv')
write.csv(ped_sum$inbreedingCoefficients, 'Ibis_ped_inbreedingCoefficients.csv')
